# STS Crane Logbook Android App

This project packages the offline STS Crane Logbook HTML dashboard inside an Android WebView.

## Build APK using GitHub Actions
1. Create a GitHub repository.
2. Upload the **contents** of this project folder to the repository root (so `.github/workflows/build-apk.yml` is at the repository root).
3. Open the repository's **Actions** tab.
4. Select **Build STS Crane Logbook APK** and press **Run workflow**.
5. When it finishes, open the run and download the artifact named **STS-Crane-Logbook-debug-apk**.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on Android.

The project ZIP is not itself an APK. GitHub Actions builds the APK.
